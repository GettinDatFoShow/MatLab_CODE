
PROB= 0.3; % probability of success

T = 20; % Num of trials 

S = 5; % Num of Successes

% Calculates the probability of 5 people attending the match in first 30 people
bino1 = 1 - binocdf(S,T,PROB);

msg = sprintf('question one');
disp(msg);
msg = sprintf('probability of 5 people attending the match in first 20 people = %2f',bino1);
disp(msg);

msg = sprintf('------------------------------------------------------------------------------');
disp(msg);
%------------------------------------------------------------------------------------------------------

PROB = 0.3; % probability of success

PROFIT = 0.1; % profit for 0.3 probability

TRIALS = 200; % Number of people selected

INC_PROFIT = 0.17;

% Calculates number people attending the match in 200 people with 0.3 success probability
NUM_PEOPLE = TRIALS*(PROB+0.12);

msg = sprintf('question two');
disp(msg);
msg = sprintf('Number people attending the match in 200 people with 0.42 probability of success = %d',NUM_PEOPLE);
disp(msg);

% Calculates the change in profit
PROFIT_CHANGE = (0.1+INC_PROFIT);

if (PROFIT_CHANGE > 0.1),
   msg = sprintf('Profit increases from 0.1 to %2f',PROFIT_CHANGE);
   disp(msg);
else if (PROFIT_CHANGE < 0.1),
        msg = sprintf('Profit decreases from 0.1 to %2f',PROFIT_CHANGE);
        disp(msg);
else if (PROFIT_CHANGE == 0.1),
        msg = sprintf('Profit stays the same as 0.1');
        disp(msg)
    end  
    end
end