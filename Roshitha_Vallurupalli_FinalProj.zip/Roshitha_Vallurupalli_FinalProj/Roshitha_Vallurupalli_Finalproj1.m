
PROB= 0.3; % probability of success

TRIALS= 200; % Number of people selected

SAMPLE = 100; % Num of times binomial is simulated

for i=1:1:SAMPLE, % binomial distribution sampling 100 times
    
    binomial=  binornd(TRIALS,PROB); % Simulates the binomail distribution
    
    msg = sprintf('Sample Num = %d',i); % sample number
    disp(msg);
    msg = sprintf('Number of successes = %d',binomial); %simulation of binomial distribution 
    disp(msg);
    
end

Average = TRIALS*PROB; % simulates the average number of people who attended the match

msg = sprintf('Average number of people who attended the match = %d',Average);                     
disp(msg);

Var = TRIALS*PROB*(1-PROB); % simulates the Variance of Binomial distribution

msg = sprintf('Variance = %d',Var);                     
disp(msg);
